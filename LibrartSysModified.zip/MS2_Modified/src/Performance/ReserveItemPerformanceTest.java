package Performance;

import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient;
import org.apache.jmeter.samplers.SampleResult;

public class ReserveItemPerformanceTest extends AbstractJavaSamplerClient {

	@Override
	public SampleResult runTest(JavaSamplerContext context) {

		SampleResult result = new SampleResult();
		result.sampleStart(); // start timing

		try {
			// simulate reservation logic only
			String membership = "MB999999";
			String callNumber = "BK1001";

			// pretend we are calling reservation logic
			// we don't need GUI — just simulate small work
			Thread.sleep(2);

			result.setSuccessful(true);
			result.setResponseMessage("Reservation simulation executed");
			result.setResponseCode("200");

		} catch (Exception e) {
			result.setSuccessful(false);
			result.setResponseMessage("Error: " + e.getMessage());
			result.setResponseCode("500");
		}

		result.sampleEnd(); // end timing
		return result;
	}
}
