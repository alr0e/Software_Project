package proxy;

import LibraryFX.Item;
import LibraryFX.LibraryData;
import LibraryFX.Member;

public class ReservationProxy implements ReservationInterface {

    private RealReservation realReservation = new RealReservation();

	@Override
	public String reserveItem(Member member, Item item) throws Exception {
		  // 🔹 1. Validate input
        if(member == null || item == null) {
            return "❌ Member or Item cannot be null";
        }

        // 🔹 2. Limit check
        if(member.getTotalReservedItems() >= 3) {
            return "❌ Reservation limit reached (3 items)";
        }

        // 🔹 3. Check if item is already reserved
        if(item.isReserved()) {
            return "❌ Item already reserved";
        }

        // 🔹 4. Delegate to real service
        return realReservation.reserveItem(member, item);
	}

 
}

