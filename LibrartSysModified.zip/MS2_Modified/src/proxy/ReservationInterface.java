package proxy;

import LibraryFX.Item;
import LibraryFX.Member;

public interface ReservationInterface {
	String reserveItem(Member member, Item item) throws Exception;


}
