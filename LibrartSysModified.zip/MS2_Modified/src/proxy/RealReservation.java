package proxy;

import LibraryFX.Item;
import LibraryFX.Member;

public class RealReservation implements ReservationInterface {
	
	  @Override
	  public String reserveItem(Member member, Item item) {
	        item.setReserved(true);
	        item.setReservedBy(member.getMembershipNumber());
	        member.addReservedItem(item.getCallNumber());

	        return "✔ SUCCESS — Item " + item.getTitle() +
	               " reserved for " + member.getName();
	    }


}
