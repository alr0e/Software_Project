package LibraryFX;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.application.Platform;

public class RegisterMemberController {
    
    @FXML private TextField nameField;
    @FXML private TextField addressField;
    @FXML private TextField financeField;
    @FXML private TextArea logArea;
    
    @FXML
    private void handleSubmit() {
        String name = nameField.getText().trim();
        String address = addressField.getText().trim();
        String financeAccount = financeField.getText().trim();

        if (name.isEmpty() || address.isEmpty() || financeAccount.isEmpty()) {
            showAlert("Error", "Please fill in all fields!", Alert.AlertType.ERROR);
            return;
        }

        logArea.setText("");

        new Thread(() -> {
            try {
                log("1. Person submits application form...");
                sleep(300);

                log("2. System stores application and alerts admin staff...");
                log("   Application ID: APP" + (int)(Math.random() * 10000));
                sleep(500);

                log("3. Admin staff reviews application and provides input...");
                log("   Status: Approved for processing");
                sleep(500);

                log("4. System contacts PearlSys for verification...");
                sleep(500);

                log("5. PearlSys sends feedback...");
                boolean isValid = LibraryData.getInstance().isValidFinanceAccount(financeAccount);
                if (!isValid) {
                    log("   ❌ FAILED: Not a valid university member");
                    log("   Application REJECTED");
                    showAlert("Application Rejected", "Not a valid university member.", Alert.AlertType.ERROR);
                    return;
                }
                log("   ✓ SUCCESS: Valid university member confirmed");
                sleep(300);

                log("6. System records feedback and accepts preliminarily...");
                sleep(300);

                log("7. System requests FinanceSys to transfer QR 1500...");
                sleep(500);

                log("8. FinanceSys processes transfer...");
                sleep(500);

                log("9. System receives transfer confirmation...");
                log("   ✓ Transfer SUCCESS: QR 1500 transferred");
                sleep(300);

                log("10. System creates membership account and deposits funds...");
                Member member = new Member(name, address, financeAccount);
                member.setDepositAmount(1500.0);
                LibraryData.getInstance().addMember(member);
                sleep(300);

                log("11. System prepares membership card with unique number...");
                log("    Membership Number: " + member.getMembershipNumber());
                sleep(300);

                log("12. Membership card sent to: " + member.getName());
                log("\n" + "=".repeat(60));
                log("✓✓✓ REGISTRATION COMPLETE ✓✓✓");
                log("Membership Number: " + member.getMembershipNumber());
                log("Member Name: " + member.getName());
                log("Deposit Amount: QR " + member.getDepositAmount());
                log("Status: ACTIVE");
                log("=".repeat(60));

                showAlert("Success!", "Membership created!\nMembership Number: " + member.getMembershipNumber(), Alert.AlertType.INFORMATION);
                clearForm();

            } catch (Exception e) {
                showAlert("Error", e.getMessage(), Alert.AlertType.ERROR);
            }
        }).start();
    }

    private void log(String message) {
        Platform.runLater(() -> logArea.appendText(message + "\n"));
    }

    private void sleep(int ms) {
        try { Thread.sleep(ms); } catch (Exception e) {}
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Platform.runLater(() -> {
            Alert alert = new Alert(type);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    private void clearForm() {
        nameField.setText("");
        addressField.setText("");
        financeField.setText("");
    }
}