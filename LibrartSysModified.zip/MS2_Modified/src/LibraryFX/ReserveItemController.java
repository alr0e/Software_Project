package LibraryFX;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import proxy.ReservationInterface;
import proxy.ReservationProxy;
import javafx.application.Platform;

public class ReserveItemController {
    
    @FXML private TextField membershipField;
    @FXML private TextField callNumberField;
    @FXML private TextArea logArea;
    @FXML private TextArea itemListArea;

    @FXML
    private void initialize() {
        updateItemList();
    }

    private void updateItemList() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-10s %-35s %s\n", "Call No.", "Title", "Year"));
        sb.append("-".repeat(60) + "\n");
        for (Item item : LibraryData.getInstance().getAllItems().values()) {
            sb.append(String.format("%-10s %-35s %d\n",
                    item.getCallNumber(), item.getTitle(), item.getYear()));
        }
        itemListArea.setText(sb.toString());
    }

    @FXML
    private void handleReserve() {String membershipNumber = membershipField.getText().trim();
    String callNumber = callNumberField.getText().trim();

    // Step 0: Check empty fields
    if (membershipNumber.isEmpty() || callNumber.isEmpty()) {
        showAlert("Error", "Please fill in all fields!", Alert.AlertType.ERROR);
        return;
    }
    logArea.setText("");

    new Thread(() -> {
        try {
            log("1. Member enters membership card...");
            sleep(300);

            log("2. System finds membership details...");
            Member member = LibraryData.getInstance().getMember(membershipNumber);
            if (member == null) {
                log("   ❌ ERROR: Invalid membership number");
                showAlert("Error", "Membership number not found!", Alert.AlertType.ERROR);
                return;
            }
            log("   Member: " + member.getName());
            sleep(500);

            log("3. System asks to enter item call number...");
            sleep(300);

            log("4. Member enters call number: " + callNumber);
            sleep(300);

            log("5. System retrieves item details...");
            Item item = LibraryData.getInstance().getItem(callNumber);

            // Proxy Being Applied
            ReservationInterface proxy = new ReservationProxy();
            String result = proxy.reserveItem(member, item);

            log("6. Proxy returns result...");
            log("   " + result);

            // Step 7: Show alert depending on result
            if (result.contains("❌")) {
                showAlert("Reservation Failed", result, Alert.AlertType.ERROR);
            } else {
                showAlert("Success!", result, Alert.AlertType.INFORMATION);
            }

            // Step 8: Update item list in panel
            updateItemList();

          
            log("--- RESERVATION PROCESS COMPLETED ---");

        } catch (Exception e) {
            showAlert("Error", e.getMessage(), Alert.AlertType.ERROR);
        }
    }).start();
}



    private void log(String message) {
        Platform.runLater(() -> logArea.appendText(message + "\n"));
    }

    private void sleep(int ms) {
        try { Thread.sleep(ms); } catch (Exception e) {}
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Platform.runLater(() -> {
            Alert alert = new Alert(type);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    private void clearForm() {
        membershipField.setText("");
        callNumberField.setText("");
    }
}