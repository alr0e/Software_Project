package LibraryFX;


public class Item {
    private String callNumber;
    private String title;
    private int year;
    private boolean isReserved;
    private String reservedBy;

    public Item(String callNumber, String title, int year) {
        this.callNumber = callNumber;
        this.title = title;
        this.year = year;
        this.isReserved = false;
    }

    public String getCallNumber() { return callNumber; }
    public String getTitle() { 
    	return title; 
    	}
    public int getYear() { 
    	return year; 
    }
    public boolean isReserved() { 
    	return isReserved; }
    
    public void setReserved(boolean reserved) { 
    	this.isReserved = reserved; }
    
    public void setReservedBy(String memberNumber) { 
    	this.reservedBy = memberNumber; }
    
    public String getReservedBy() { 
    	return reservedBy; }
}