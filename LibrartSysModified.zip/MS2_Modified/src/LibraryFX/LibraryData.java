package LibraryFX;

import java.util.*;

public class LibraryData {
    private static LibraryData instance;
    private Map<String, Member> members = new HashMap<>();
    private Map<String, Item> items = new HashMap<>();
    private Set<String> validFinanceAccounts = new HashSet<>();

    public LibraryData() {
        // Initialize test data
        validFinanceAccounts.addAll(Arrays.asList("FIN001", "FIN002", "FIN003", "FIN004", "FIN005"));

        // Add sample items
        items.put("BK1001", new Item("BK1001", "Introduction to Java", 2020));
        items.put("BK1002", new Item("BK1002", "Database Systems", 2019));
        items.put("BK1003", new Item("BK1003", "Software Engineering", 2021));
        items.put("DM2001", new Item("DM2001", "Learning Python DVD", 2022));
        items.put("MG3001", new Item("MG3001", "Tech Magazine May 2024", 2024));
    }

    public static LibraryData getInstance() {
        if (instance == null) {
            instance = new LibraryData();
        }
        return instance;
    }

    public boolean isValidFinanceAccount(String account) {
        return validFinanceAccounts.contains(account);
    }
    
    public Map<String, Member> getMembers() {
        return members;
    }


    public boolean addMember(Member member) {
        if (members.containsKey(member.getMembershipNumber())) {
            return false; // member already exists
        }
        members.put(member.getMembershipNumber(), member);
        return true;
    }
    public Member getMember(String membershipNumber) {
        return members.get(membershipNumber);
    }
    
    public Member findMember(String membershipNumber) {
        return members.get(membershipNumber);
    }

    
    
    public Item getItem(String callNumber) {
        return items.get(callNumber);
    }

    public Map<String, Item> getAllItems() {
        return items;
    }
    public void addItem(Item item) {
        items.put(item.getCallNumber(), item);
    }


    // Add these methods to display stored data
    public void displayAllMembers() {
        System.out.println("\n=== ALL REGISTERED MEMBERS ===");
        if (members.isEmpty()) {
            System.out.println("No members registered yet.");
        } else {
            for (Member member : members.values()) {
                System.out.println("Membership No: " + member.getMembershipNumber());
                System.out.println("Name: " + member.getName());
                System.out.println("Address: " + member.getAddress());
                System.out.println("Finance Account: " + member.getFinanceAccount());
                System.out.println("Deposit: QR " + member.getDepositAmount());
                System.out.println("Reserved Items: " + member.getTotalReservedItems());
                System.out.println("Reserved Items List: " + member.getReservedItems());
                System.out.println("------------------------");
            }
        }
    }

    public void displayAllItems() {
        System.out.println("\n=== ALL LIBRARY ITEMS ===");
        for (Item item : items.values()) {
            System.out.println("Call No: " + item.getCallNumber());
            System.out.println("Title: " + item.getTitle());
            System.out.println("Year: " + item.getYear());
            System.out.println("Reserved: " + item.isReserved());
            System.out.println("Reserved By: " + item.getReservedBy());
            System.out.println("------------------------");
        }
    }

    public void displayValidFinanceAccounts() {
        System.out.println("\n=== VALID FINANCE ACCOUNTS (PearlSys) ===");
        for (String account : validFinanceAccounts) {
            System.out.println("Account: " + account);
        }
    }
}