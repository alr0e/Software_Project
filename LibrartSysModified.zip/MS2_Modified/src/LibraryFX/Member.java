package LibraryFX;

import java.util.*;

public class Member {
    private String membershipNumber;
    private String name;
    private String address;
    private String financeAccount;
    private int totalReservedItems;
    private double depositAmount;
    private List<String> reservedItems;

    public Member(String name, String address, String financeAccount) {
    	this.membershipNumber = "MB" + (100000 + new Random().nextInt(900000));
        this.name = name;
        this.address = address;
        this.financeAccount = financeAccount;
        this.totalReservedItems = 0;
        this.depositAmount = 0;
        this.reservedItems = new ArrayList<>();
    }

    public String getMembershipNumber() { return membershipNumber; }
    public String getName() { return name; }
    public int getTotalReservedItems() { return totalReservedItems; }
    public void setDepositAmount(double amount) { this.depositAmount = amount; }
    public double getDepositAmount() { return depositAmount; }
    public List<String> getReservedItems() { return reservedItems; }
    public void addReservedItem(String callNumber) {
        reservedItems.add(callNumber);
        totalReservedItems++;
    }

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFinanceAccount() {
		return financeAccount;
	}

	public void setFinanceAccount(String financeAccount) {
		this.financeAccount = financeAccount;
	}
	public boolean canReserveMore() {
	    return totalReservedItems < 3;
	}
}