package factory;
public class TestItemFactory {

    public static void main(String[] args) {

        ItemStore store = new ItemStore();

        Item i1 = store.requestItem("BOOK");
        System.out.println(i1.getLoanPeriod());

        Item i2 = store.requestItem("MAGAZINE");
        System.out.println(i2.getLoanPeriod());
    }
}