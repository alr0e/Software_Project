package factory;
public class ItemFactory {

    public Item getItem(String type) {

        if(type == null) return null;

        if(type.equalsIgnoreCase("BOOK"))
            return new Book();

        if(type.equalsIgnoreCase("MAGAZINE"))
            return new Magazine();

        if(type.equalsIgnoreCase("DIGITAL"))
            return new digitalmedia();

        return null;
    }
}