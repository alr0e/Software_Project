package factory;
public class Book implements Item {

    private int loanPeriod = 4;

    @Override
    public int getLoanPeriod() {
        return loanPeriod;
    }

    @Override
    public boolean checkAvailability() { return true; }

    @Override
    public boolean canBeExtended() { return true; }

    @Override
    public void updateStatus(String status) {}

    @Override
    public String generateReport() { return "Book2 Report"; }
}