package factory;
public class ItemStore {

    private ItemFactory factory;

    public ItemStore() {
        factory = new ItemFactory();
    }

    public Item requestItem(String type) {
        return factory.getItem(type);
    }
}