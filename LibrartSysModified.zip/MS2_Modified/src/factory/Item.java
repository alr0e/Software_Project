package factory;
public interface Item {

    int getLoanPeriod();

    boolean checkAvailability();

    boolean canBeExtended();

    void updateStatus(String status);

    String generateReport();
}