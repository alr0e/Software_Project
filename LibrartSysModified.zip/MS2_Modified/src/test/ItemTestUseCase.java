package test;

import static org.junit.Assert.*;

import org.junit.Test;

import LibraryFX.Item;

public class ItemTestUseCase {

    @Test
    public void testItemInitialization() {
        Item item = new Item("BK1001", "Java Book", 2020);
        assertEquals("BK1001", item.getCallNumber());
        assertEquals("Java Book", item.getTitle());
        assertEquals(2020, item.getYear());
        assertFalse(item.isReserved());  // must be false initially
    }

    @Test
    public void testReserveFlag() {
        Item item = new Item("BK2001", "Python Book", 2021);
        item.setReserved(true);
        assertTrue(item.isReserved());
    }

    @Test
    public void testReservedBySetterGetter() {
        Item item = new Item("BK3001", "Database Systems", 2019);
        item.setReservedBy("MB123456");
        assertEquals("MB123456", item.getReservedBy());
    }
}
