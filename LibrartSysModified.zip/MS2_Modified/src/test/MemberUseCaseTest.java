package test;

import static org.junit.Assert.*;
import org.junit.Test;

import LibraryFX.Member;

import java.util.List;

public class MemberUseCaseTest {
	@Test
    public void testMemberInitialization() {
        Member m = new Member("Ali", "Doha", "FIN001");
        m.setDepositAmount(1500);  // manually set it
        assertEquals("Ali", m.getName());
        assertEquals("Doha", m.getAddress());
        assertEquals("FIN001", m.getFinanceAccount());
        assertEquals(1500, m.getDepositAmount(), 0.001); // default deposit
    }

    @Test
    public void testMemberNumberFormat() {
        Member m = new Member("Sara", "Wakra", "FIN002");
        assertTrue(m.getMembershipNumber().startsWith("MB"));
        assertEquals(8, m.getMembershipNumber().length()); // Example: MB123456
    }

    @Test
    public void testCanReserveWhenUnderLimit() {
        Member m = new Member("Ahmad", "Rayyan", "FIN003");
        for(int i = 0; i < 2; i++) 
            m.addReservedItem("BK00" + i);

        assertTrue(m.canReserveMore()); // still under 3
    }

    @Test
    public void testCannotReserveMoreThanThree() {
        Member m = new Member("Fatima", "Lusail", "FIN004");
        for(int i = 0; i < 3; i++) 
            m.addReservedItem("BK00" + i);

        assertFalse(m.canReserveMore()); // limit reached
    }

    @Test
    public void testReservedItemsAddedCorrectly() {
        Member m = new Member("Mona", "Doha", "FIN005");
        m.addReservedItem("BK1001");

        List<String> reserved = m.getReservedItems();
        assertTrue(reserved.contains("BK1001"));
        assertEquals(1, reserved.size());
    }
}