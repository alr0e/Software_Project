package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import LibraryFX.Member; 
import LibraryFX.Item;  
import LibraryFX.LibraryData;

public class LibraryDataUseCaseTest {

    private LibraryData data;

    @Before
    public void setUp() {
        data = new LibraryData();
        data.getAllItems().clear(); 
    }

    @Test
    public void testAddMember() {
        Member m = new Member("Ali", "Doha", "FIN001"); 
        boolean result = data.addMember(m);
        assertTrue(result);
    }

    @Test
    public void testSearchMemberFound() {
        Member m = new Member("Ali", "Doha", "FIN001");
        data.addMember(m);
        Member foundMember = data.findMember(m.getMembershipNumber()); // Use the actual membership number
        assertNotNull(foundMember);
        assertEquals("Ali", foundMember.getName());
    }

    @Test
    public void testAddItem() {
        Item item = new Item("TEST001", "Test Book", 2024);
        data.addItem(item);
        assertEquals(1, data.getAllItems().size());
    }
}
